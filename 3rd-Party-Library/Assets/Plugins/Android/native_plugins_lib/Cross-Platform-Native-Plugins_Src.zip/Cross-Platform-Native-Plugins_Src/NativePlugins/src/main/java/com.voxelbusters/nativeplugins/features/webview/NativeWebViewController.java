package com.voxelbusters.nativeplugins.features.webview;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.app.Activity;
import android.app.FragmentTransaction;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.ResultReceiver;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.ConsoleMessage;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions.Callback;
import android.webkit.JsResult;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebSettings.LayoutAlgorithm;
import android.webkit.WebSettings.PluginState;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.unity3d.player.UnityPlayer;
import com.unity3d.player.UnityPlayerActivity;
import com.voxelbusters.nativeplugins.NativePluginHelper;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.defines.Keys;
import com.voxelbusters.nativeplugins.defines.UnityDefines;
import com.voxelbusters.nativeplugins.helpers.interfaces.IKeyboardListener;
import com.voxelbusters.nativeplugins.utilities.Debug;

import java.lang.reflect.Field;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;

enum eWebViewEvent
{
	ePageLoadStarted, ePageLoadEnded
}

// This is for creating a webview and presenting it
public class NativeWebViewController extends WebViewClient implements IKeyboardListener {
	private final String tag;
	private NativeWebViewFrame webViewDialog;
	private boolean showLoadingOnLoad;

	volatile private boolean autoShowAfterLoad;
	private boolean canHide;
	private boolean isLoading;

	private boolean isShowing;

	private boolean canGoBack = true;
	private boolean canGoForward = true;

	private boolean isFullScreen = false;

	public JavaScriptInterface javaScriptInterface;

	ArrayList<String> supportedSchemaList = new ArrayList<String>();
	RectF frameRect = new RectF();

	final String PDF_OPENER_PREFIX = "http://docs.google.com/gview?embedded=true&url=";

	public NativeWebViewController(String tag, RectF frameRect) {
		this.tag = tag;
		this.frameRect = frameRect;
	}

	public NativeWebViewController(Activity activity, String tag) {
		this.tag = tag;
		CreateDefaultWebView(activity);
	}

	public void SetFullScreenMode(boolean isFullScreen)
	{
		if(isFullScreen !=  this.isFullScreen)
		{
			this.isFullScreen = isFullScreen;

			if(webViewDialog != null) {
				// If set to full screen just remove it self from its parent view
				if (isFullScreen) {
					ViewGroup parent = (ViewGroup) webViewDialog.getParent();
					parent.removeView(webViewDialog);

					if (isShowing) {
						WebviewActivity.show(tag);
					}
				} else {
					if (isShowing) {
						WebviewActivity.close();
					}
					NativePluginHelper.getCurrentActivity().addContentView(webViewDialog, webViewDialog.getLayoutParams());
				}
			}
		}
	}

	public boolean IsFullScreenMode()
	{
		return  isFullScreen;
	}


	@SuppressLint("NewApi")
	public void CreateDefaultWebView(Activity parentActivity)
	{
		webViewDialog = new NativeWebViewFrame(parentActivity);
		webViewDialog.requestFocusFromTouch();

		if(!isFullScreen)
		{
			parentActivity.addContentView(webViewDialog, webViewDialog.getLayoutParams());
		}

		setDefaultWebViewSettings(parentActivity);

		getWebView().setWebViewClient(this);
		setWebChromeClientListeners();

		//For enabling html5 videos
		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB)
		{
			getWebView().setLayerType(View.LAYER_TYPE_HARDWARE, null);
		}

		webViewDialog.hide();

		javaScriptInterface = new JavaScriptInterface(tag);
		getWebView().addJavascriptInterface(javaScriptInterface, "UnityInterface");

		//By default we set to autoShowOnComplete. And this will be overriden by show call.
		setAutoShowWhenLoadComplete(true);
		setControlType(Keys.WebView.TYPE_CLOSE_BUTTON);

		registerButtonCallbacks();

		setFrame(frameRect);

		//Set adjust resize flag
		parentActivity.getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);
	}

	void registerButtonCallbacks()
	{

		NativeWebViewToolBar toolbar = webViewDialog.getToolBar();
		toolbar.getBackButton().setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View v)
			{
				getWebView().goBack();
			}
		});

		toolbar.getForwardButton().setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View v)
			{
				getWebView().goForward();
			}
		});

		toolbar.getReloadButton().setOnClickListener(new OnClickListener()
		{

			@Override
			public void onClick(View v)
			{
				getWebView().reload();
			}
		});

		OnClickListener closeListener = new OnClickListener()
		{
			@Override
			public void onClick(View v)
			{
				hide();
			}
		};

		toolbar.getCloseButton().setOnClickListener(closeListener);

		webViewDialog.setCloseButtonListener(closeListener);

	}

	public void setDefaultWebViewSettings(Activity parentActivity)
	{
		WebSettings settings = getWebView().getSettings();

		if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.JELLY_BEAN_MR2)
		{
			settings.setPluginState(PluginState.ON);
		}

		settings.setJavaScriptEnabled(true);
		settings.setJavaScriptCanOpenWindowsAutomatically(true);
		settings.setAllowFileAccess(true);
		settings.setDomStorageEnabled(true);

		// No cache by default
		settings.setCacheMode(WebSettings.LOAD_NO_CACHE);

		// Setting zoom by default to false
		settings.setSupportZoom(false);

		settings.setDatabaseEnabled(true);

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN)
		{
			settings.setAllowUniversalAccessFromFileURLs(true);
		}

		settings.setGeolocationDatabasePath(parentActivity.getFilesDir().getPath());

		// cookies
		CookieManager cookieManager = CookieManager.getInstance();
		cookieManager.setAcceptCookie(true);

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP)
		{
			cookieManager.setAcceptThirdPartyCookies(getWebView(), true);
		}
	}

	void setWebChromeClientListeners()
	{

		getWebView().setWebChromeClient(new WebChromeClient()
		{

			@Override
			public boolean onJsConfirm(WebView view, String url, String message, JsResult result)
			{
				// TODO Auto-generated method stub
				return super.onJsConfirm(view, url, message, result);
			}

			@Override
			public boolean onJsAlert(WebView view, String url, String message, JsResult result)
			{
				return super.onJsAlert(view, url, message, result);
			}

			@Override
			public boolean onConsoleMessage(ConsoleMessage consoleMessage)
			{

				Debug.log(CommonDefines.WEB_VIEW_TAG, "message:" + consoleMessage.message(), true);

				return super.onConsoleMessage(consoleMessage);
			}

			@Override
			public void onGeolocationPermissionsShowPrompt(String origin, Callback callback)
			{
				callback.invoke(origin, true, false);//For obtaining permission.
			}


			// < 3.0
			public void openFileChooser(ValueCallback<Uri> callback)
			{
				openFileChooser(callback, "*/*");
			}

			// > 3.0+
			public void openFileChooser(ValueCallback<Uri> callback, String acceptType)
			{
				launchFileChooserActivity(new SerialisedValueCallback(callback), "*/*", false);
			}

			// > 4.1+
			public void openFileChooser(ValueCallback<Uri> callback, String acceptType, String capture)
			{
				openFileChooser(callback, "*/*");
			}

			// > 5.0+
			public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback, WebChromeClient.FileChooserParams fileChooserParams)
			{
				launchFileChooserActivity(new SerialisedValueCallback(callback), "image/*", true);
				return true;
			}

			private void launchFileChooserActivity(final SerialisedValueCallback callback, String acceptType, final boolean isCallbackArray)
			{

				final FileChooserFragment request = new FileChooserFragment();
				request.setCallback(new ResultReceiver(null){
					@Override
					protected void onReceiveResult(int resultCode, Bundle resultData)
					{
						Uri uri = resultData.getParcelable("DATA");
						if(isCallbackArray)
						{
							callback.onReceiveValue(new Uri[]{uri});
						}
						else
						{
							callback.onReceiveValue(uri);
						}
					}
				});
				Bundle bundle = new Bundle();

				bundle.putString(Keys.TYPE, Keys.WebView.FILE_CHOOSER);
				bundle.putString(Keys.WebView.ACCEPTABLE_DATA_MIME, acceptType);

				request.setArguments(bundle);
				FragmentTransaction fragmentTransaction = NativePluginHelper.getCurrentActivity().getFragmentManager().beginTransaction();
				fragmentTransaction.add(0, request);
				fragmentTransaction.commit();
			}

			@Override
			public void onPermissionRequest(final PermissionRequest request) {

				Runnable runnable = (new Runnable()
				{
					@TargetApi(Build.VERSION_CODES.LOLLIPOP)
					@Override
					public void run()
					{
							request.grant(request.getResources());
					}
				});

				NativePluginHelper.executeOnUIThread(runnable);
			}


			//TODO Yet to support full screen for html 5
			//Support for older devices
				/*@Override
				public void onShowCustomView(View view, CustomViewCallback callback)
				{
					super.onShowCustomView(view, callback);
				}

				@Override
				public void onHideCustomView()
				{
					super.onHideCustomView();
				}

				@Override
				public View getVideoLoadingProgressView()
				{

					return super.getVideoLoadingProgressView();

				}*/

		});
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// / Accessors Functions///
	// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public String getTag()
	{
		return tag;
	}

	public WebView getWebView()
	{
		return webViewDialog.getWebView();
	}

	public boolean isShowLoadingOnLoad()
	{
		return showLoadingOnLoad;
	}

	public void setShowLoadingOnLoad(boolean showLoadingOnLoad)
	{
		this.showLoadingOnLoad = showLoadingOnLoad;
		showLoadingDialogIfNeeded();
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// / Memory Management Functions///
	// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	public void destroy()
	{
		webViewDialog.dismissAndDestroy();
		if(isFullScreen)
		{
			WebviewActivity.close();
		}
	}

	public void loadURL(String urlString) throws MalformedURLException
	{
		Debug.log(CommonDefines.WEB_VIEW_TAG, "Loading : " + urlString, true);
		getWebView().loadUrl(urlString);
	}

	public void loadDataWithBaseURL(String baseURLStr, String data, String mimeType, String encoding, String hisotryURL)
	{
		getWebView().loadDataWithBaseURL(baseURLStr, data, mimeType, encoding, hisotryURL);
	}

	public void loadData(String data, String mimeType, String encoding)
	{
		getWebView().loadData(data, mimeType, encoding);
	}

	public void reload()
	{
		getWebView().reload();
	}

	public void show(Activity parentActivity)
	{
		webViewDialog.setUpLayout();
		parentActivity.setContentView(webViewDialog, webViewDialog.getLayoutParams());
		show();
	}

	public void show()
	{
		if (!isShowing)
		{
			isShowing = true;
			webViewDialog.showNow();
			NativePluginHelper.sendMessage(UnityDefines.WebView.WEB_VIEW_DID_SHOW, tag);
		}
	}

	public boolean isVisible()
	{
		return isShowing;
	}

	public void stop()
	{
		getWebView().stopLoading();
		hideLoadingDialog();
	}

	public void hide()
	{
		if (isShowing)
		{
			isShowing = false;
			webViewDialog.hide();
			NativePluginHelper.sendMessage(UnityDefines.WebView.WEB_VIEW_DID_HIDE, tag);

			if(isFullScreen)
			{
				WebviewActivity.close();
			}
		}
	}

	public boolean isCanHide()
	{
		return canHide;
	}

	public void setCanHide(boolean canHide)
	{
		this.canHide = canHide;

		//Disable the close buttons if canHide is false

		webViewDialog.getToolBar().getBackButton().setEnabled(canHide);
		webViewDialog.getCloseButton().setEnabled(canHide);

	}

	@SuppressLint("NewApi")
	public void stringByEvaluatingJavaScriptFromString(String jsScript)
	{

		if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT)
		{
			getWebView().evaluateJavascript("javascript:" + jsScript, new ValueCallback<String>()
			{
				@Override
				public void onReceiveValue(String result)
				{
					javaScriptInterface.passToUnity(result);
				}
			});
		}
		else
		{
			try
			{
				loadURL("javascript:UnityInterface.passToUnity(" + jsScript + ")");//Just injecting our interface call along with the passed js script
			}
			catch (MalformedURLException e)
			{
				Debug.error(CommonDefines.WEB_VIEW_TAG, "Exception in stringByEvaluatingJavaScriptFromString");
				e.printStackTrace();
				javaScriptInterface.passToUnity("[Error] " + e.getMessage());
			}
		}
	}

	public void setBounce(boolean canBounce)
	{
		if (canBounce)
		{
			getWebView().setOverScrollMode(View.OVER_SCROLL_NEVER);
		}
		else
		{
			getWebView().setOverScrollMode(View.OVER_SCROLL_IF_CONTENT_SCROLLS);
		}
	}

	public void setCanGoBack(boolean canGoBack)
	{
		this.canGoBack = canGoBack;
	}

	public void showLoadingIndicatorOnLoad(boolean showLoading)
	{
		setShowLoadingOnLoad(showLoading);
	}

	public void setAutoShowWhenLoadComplete(boolean autoShow)
	{
		autoShowAfterLoad = autoShow;

		if (autoShowAfterLoad && isLoading)
		{
			hide();
		}
	}

	public void setScalesPageToFit(boolean scaleToFit)
	{
		// TODO Auto-generated method stub
		getWebView().getSettings().setLoadWithOverviewMode(true);
		getWebView().getSettings().setUseWideViewPort(true);
		getWebView().getSettings().setLayoutAlgorithm(LayoutAlgorithm.NORMAL);
		getWebView().setInitialScale(1);
	}

	public void setZoom(boolean enable)
	{
		getWebView().getSettings().setBuiltInZoomControls(true);
		getWebView().getSettings().setSupportZoom(true);
	}

	public void setFrame(float x, float y, float width, float height)
	{
		frameRect.left = x;
		frameRect.top = y;
		frameRect.right = x + width;
		frameRect.bottom = y + height;

		webViewDialog.setFrame(frameRect);
	}

	public void setFrame(RectF frameRect)
	{
		this.frameRect = frameRect;
		webViewDialog.setFrame(frameRect);
	}

	public void addNewScheme(String newSchema)
	{
		//TODO
		//This schema should be considered to check if we need to process the new url request we got
		supportedSchemaList.add(newSchema);
	}

	public void removeScheme(String newSchema)
	{
		//TODO
		//This schema should be considered to check if we need to process the new url request we got
		supportedSchemaList.remove(newSchema);
	}

	public void clearCache()
	{
		getWebView().clearCache(true);
	}

	public void setNavigation(boolean canGoBack, boolean canGoForward)
	{
		//Set the toolbar options accordingly
		this.canGoBack = canGoBack;
		this.canGoForward = canGoForward;

		//Update toolbar buttons
		setUpToolbarButtons();
	}

	public void setControlType(String type)
	{

		webViewDialog.getToolBar().hide();
		webViewDialog.hideCloseButton();

		if (type.equals(Keys.WebView.TYPE_TOOLBAR))
		{
			webViewDialog.getToolBar().show();
			setNavigation(true, true);
		}
		else if (type.equals(Keys.WebView.TYPE_CLOSE_BUTTON))
		{
			webViewDialog.showCloseButton();
		}
	}

	public void setShowToolBar(boolean showToolBar)
	{
		if (!showToolBar)
		{
			webViewDialog.getToolBar().hide();
		}
		else
		{
			webViewDialog.getToolBar().show();
		}
	}

	public void setBackgroundColor(int red, int green, int blue, int alpha)
	{
		getWebView().setBackgroundColor(Color.argb(alpha, red, green, blue));
	}

	// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
	// / Callbacks
	// //////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

	@Override
	public void onPageStarted(WebView view, String url, Bitmap favicon)
	{
		super.onPageStarted(view, url, favicon);

		isLoading = true;

		showLoadingDialogIfNeeded();

		//Update toolbar buttons
		setUpToolbarButtons();

		NativePluginHelper.sendMessage(UnityDefines.WebView.WEB_VIEW_DID_START_LOAD, tag);

	}

	@Override
	public void onPageFinished(WebView view, String url)
	{
		super.onPageFinished(view, url);

		isLoading = false;

		if (autoShowAfterLoad)
		{
			getWebviewFrame().getWebView().refreshDrawableState();

			Runnable runnableThread = new Runnable()
			{
				@Override
				public void run()
				{
					if(isFullScreen)
					{
						if (WebviewActivity.currentInstance == null)
							WebviewActivity.show(tag);
					}
					else
					{
						show();
					}
				}
			};

			NativePluginHelper.executeOnUIThread(runnableThread);
		}

		hideLoadingDialog();

		//Update toolbar buttons
		setUpToolbarButtons();

		HashMap<String, String> data = new HashMap<String, String>();
		data.put(Keys.TAG, tag);
		data.put(Keys.URL, url);

		NativePluginHelper.sendMessage(UnityDefines.WebView.WEB_VIEW_DID_FINISH_LOAD, data);


	}

	@Override
	public void onReceivedError(WebView view, int errorCode, String description, String failingUrl)
	{
		super.onReceivedError(view, errorCode, description, failingUrl);

		isLoading = false;

		if (autoShowAfterLoad)
		{
			Runnable runnableThread = new Runnable()
			{
				@Override
				public void run()
				{
					if(isFullScreen)
					{
						if (WebviewActivity.currentInstance == null)
							WebviewActivity.show(tag);
					}
					else
					{
						show();
					}
				}
			};

			NativePluginHelper.executeOnUIThread(runnableThread);
		}

		hideLoadingDialog();

		//Update toolbar buttons
		setUpToolbarButtons();

		Debug.error(CommonDefines.WEB_VIEW_TAG, "Received Error : " + description);

		HashMap<String, String> data = new HashMap<String, String>();
		data.put(Keys.TAG, tag);
		data.put(Keys.ERROR, description);
		data.put(Keys.URL, failingUrl);

		NativePluginHelper.sendMessage(UnityDefines.WebView.WEB_VIEW_DID_FAIL_LOAD_WITH_ERROR, data);
	}

	@Override
	public boolean shouldOverrideUrlLoading(WebView view, String urlString)
	{
		Debug.log(CommonDefines.WEB_VIEW_TAG, "URL STRING = " + urlString);

		//First filter userScemelist then move on to default handling
		Uri uri = Uri.parse(urlString);
		String schemeOfUrl = uri.getScheme();

		if (supportedSchemaList.contains(schemeOfUrl))
		{
			//Pass this info to unity.
			parseCustomScheme(uri);
			return true;
		}
		else
		{
			if (urlString != null && urlString.startsWith("intent://")) {
				try {
					Intent intent = Intent.parseUri(urlString, Intent.URI_INTENT_SCHEME);
					Intent existPackage = NativePluginHelper.getCurrentContext().getPackageManager().getLaunchIntentForPackage(intent.getPackage());
					if (existPackage != null) {
						NativePluginHelper.startActivityOnUiThread(intent);
					} else {
						Intent marketIntent = new Intent(Intent.ACTION_VIEW);
						marketIntent.setData(Uri.parse("market://details?id="+intent.getPackage()));
						NativePluginHelper.startActivityOnUiThread(marketIntent);
					}
					return true;
				}catch (Exception e) {
					e.printStackTrace();
				}
			} else if (urlString != null && urlString.startsWith("market://")) {
				try {
					Intent intent = Intent.parseUri(urlString, Intent.URI_INTENT_SCHEME);
					if (intent != null) {
						NativePluginHelper.startActivityOnUiThread(intent);
					}
					return true;
				} catch (URISyntaxException e) {
					e.printStackTrace();
				}
			}
			else if(uri != null && !urlString.startsWith(PDF_OPENER_PREFIX) && uri.getPath().endsWith(".pdf"))
			{
				try
				{
					loadURL(PDF_OPENER_PREFIX+urlString);
				}
				catch (MalformedURLException e)
				{
					e.printStackTrace();
				}
				return  true;
			}
			return false;
		}
	}

	private void parseCustomScheme(Uri uri)
	{
		String url = uri.toString();
		String host = uri.getHost();
		String scheme = uri.getScheme();
		String query = uri.getQuery();

		HashMap<String, String> keyValueMap = new HashMap<String, String>();

		if (query != null)
		{
			String[] keyValuePairs = query.split("&");

			if (keyValuePairs != null)
			{
				for (String keyValuePair : keyValuePairs)
				{
					String[] keyAndValue = keyValuePair.split("=");
					String key = keyAndValue[0];
					String value = "";
					if (keyAndValue.length > 1)
					{
						value = keyAndValue[1];
					}
					keyValueMap.put(key, value);
				}
			}
		}

		HashMap<String, Object> hash = new HashMap<String, Object>();

		HashMap<String, Object> subHash = new HashMap<String, Object>();

		subHash.put(Keys.URL, url != null ? url : "");
		subHash.put(Keys.WebView.HOST, host != null ? host : "");
		subHash.put(Keys.WebView.ARGUMENTS, keyValueMap);
		subHash.put(Keys.WebView.URL_SCHEME, scheme);

		hash.put(Keys.WebView.TAG, tag);
		hash.put(Keys.WebView.MESSAGE_DATA, subHash);

		NativePluginHelper.sendMessage(UnityDefines.WebView.WEB_VIEW_DID_RECEIVE_MESSAGE, hash);
	}

	void setUpToolbarButtons()
	{
		//Setup toolbar options
		NativeWebViewToolBar toolBar = webViewDialog.getToolBar();

		toolBar.getBackButton().setEnabled((getWebView().canGoBack() && canGoBack));

		toolBar.getForwardButton().setEnabled((getWebView().canGoForward() && canGoForward));

	}

	void showLoadingDialogIfNeeded()
	{

		if (isLoading && showLoadingOnLoad)
		{
			webViewDialog.showProgressSpinner();
		}
		else
		{
			webViewDialog.hideProgressSpinner();
		}
	}

	void hideLoadingDialog()
	{
		webViewDialog.hideProgressSpinner();
	}

	@Override
	public void onKeyboardVisibilityChange(boolean isVisible)
	{
		//@@webViewDialog.adjustKeyboard(isVisible);
	}

	public NativeWebViewFrame getWebviewFrame()
	{
		return webViewDialog;
	}

	public void setUnityStatus(boolean isActive)
	{
		UnityPlayerActivity activity = (UnityPlayerActivity)NativePluginHelper.getCurrentActivity();

		Field protectedField = null;

		try {
			protectedField = activity.getClass().getDeclaredField("mUnityPlayer");
		} catch (NoSuchFieldException e) {
			e.printStackTrace();
		}

		//this call allows private fields to be accessed via reflection
		protectedField.setAccessible(true);

		//getting value of private field using reflection
		UnityPlayer unityPlayer = null;
		try {
			unityPlayer = (UnityPlayer) protectedField.get(activity);
			if(isActive)
				unityPlayer.resume();
			else
				unityPlayer.pause();

		} catch (IllegalAccessException e) {
			e.printStackTrace();
		}

	}
}
