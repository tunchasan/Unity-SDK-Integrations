package com.voxelbusters.nativeplugins.features.notification.serviceprovider.fcm;

import android.content.Context;
import android.os.AsyncTask;
import android.support.annotation.NonNull;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessaging;
import com.voxelbusters.nativeplugins.defines.CommonDefines;
import com.voxelbusters.nativeplugins.features.notification.core.BasicRemoteNotificationService;
import com.voxelbusters.nativeplugins.features.notification.core.RemoteNotificationRegistrationInfo;
import com.voxelbusters.nativeplugins.utilities.ApplicationUtility;
import com.voxelbusters.nativeplugins.utilities.Debug;

import java.io.IOException;

public class FCM extends BasicRemoteNotificationService
{
	public FCM(Context context)
	{
		super(context);
		// TODO Auto-generated constructor stub
		FirebaseMessaging.getInstance().setAutoInitEnabled(false);
	}

	FirebaseMessaging service;

	@Override
	public void register(String[] senderIDs)
	{
		service = FirebaseMessaging.getInstance();
		fetchToken();//Make sure we disable auto init
	}

	@Override
	public void unRegister()
	{
		if (service != null)
		{
			unRegisterInBackground();
		}
	}

	@Override
	public boolean isAvailable()
	{
		boolean playServicesAvailable = ApplicationUtility.isGooglePlayServicesAvailable(context, false);

		return playServicesAvailable;
	}


	private void fetchToken()
	{

		FirebaseInstanceId.getInstance().getInstanceId()
				.addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
					@Override
					public void onComplete(@NonNull Task<InstanceIdResult> task) {
						RemoteNotificationRegistrationInfo registrationInfo = new RemoteNotificationRegistrationInfo();
						registrationInfo.registrationId = null;

						if (!task.isSuccessful()) {
							Log.w(CommonDefines.NOTIFICATION_TAG, "getInstanceId failed", task.getException());
							registrationInfo.errorMsg = task.getException().toString();
							FCM.this.getListener().onReceivingRegistrationID(registrationInfo);
							return;
						}

						// Get new Instance ID token
						String token = task.getResult().getToken();

						Debug.error(CommonDefines.NOTIFICATION_TAG, token);
						registrationInfo.registrationId = token;

						FCM.this.getListener().onReceivingRegistrationID(registrationInfo);
					}
				});
	}
/*
	// Registration and UnRegistration are blocked calls. so should be in
	// seperate threads
	private void registerInBackground(final String[] senderIDs)
	{
		new AsyncTask<String, Void, RemoteNotificationRegistrationInfo>()
			{

				@Override
				protected RemoteNotificationRegistrationInfo doInBackground(String... params)
				{
					RemoteNotificationRegistrationInfo registrationInfo = new RemoteNotificationRegistrationInfo();
					registrationInfo.registrationId = null;

					try
					{
						registrationInfo.registrationId = service.register(senderIDs);
						Debug.log(CommonDefines.NOTIFICATION_TAG, "GCM Registration ID = " + registrationInfo.registrationId);

					}
					catch (Exception ex)
					{
						String error = ex.getMessage();
						Debug.error(CommonDefines.NOTIFICATION_TAG, "GCM Registration Failed : " + error);
						registrationInfo.errorMsg = error;
					}

					return registrationInfo;
				}

				@Override
				protected void onPostExecute(RemoteNotificationRegistrationInfo result)
				{
					FCM.this.getListener().onReceivingRegistrationID(result);
				}

			}.execute(null, null, null);
	}
*/
	private void unRegisterInBackground()
	{
		new AsyncTask<Void, Void, String>()
			{

				@Override
				protected String doInBackground(Void... params)
				{
					String status = "SUCCESS";
					try
					{
						FirebaseInstanceId.getInstance().deleteInstanceId();
					}
					catch (IOException ex)
					{
						status = "FAILED : " + ex.getMessage();
					}

					return status;
				}

				@Override
				protected void onPostExecute(String status)
				{
					FCM.this.getListener().onUnRegistration(status);
				}

			}.execute(null, null, null);
	}
}
