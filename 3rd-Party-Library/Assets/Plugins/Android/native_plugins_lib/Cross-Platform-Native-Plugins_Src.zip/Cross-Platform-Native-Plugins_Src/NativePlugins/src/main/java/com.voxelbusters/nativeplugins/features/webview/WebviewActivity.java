package com.voxelbusters.nativeplugins.features.webview;

import android.app.Activity;
import android.app.Dialog;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;

import com.voxelbusters.nativeplugins.NativePluginHelper;

public class WebviewActivity extends Activity
{
    Bundle bundleInfo;
    public static WebviewActivity currentInstance;
    NativeWebViewFrame webViewFrame;

    @Override
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);

        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
                WindowManager.LayoutParams.FLAG_FULLSCREEN);

        currentInstance = this;

        if (bundleInfo == null)
        {
            Intent intent = getIntent();
            bundleInfo = intent.getExtras();

            String tag = bundleInfo.getString("Tag");

            NativeWebViewController webViewController = WebViewHandler.getInstance().getNativeWebViewWithTag(tag);


            if (webViewController == null)
            {
                return;
            }

            webViewFrame = webViewController.getWebviewFrame();

            // Remove the view if this exists somewhere
            ViewGroup parent = (ViewGroup) webViewFrame.getParent();
            if(parent != null)
            {
                parent.removeView(webViewFrame);
            }

            webViewController.show(this);

           /* Dialog dialog = new Dialog(this, android.R.style.Theme_Light);
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
            dialog.setContentView(webViewFrame);
            dialog.show();*/
        }


    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (currentInstance  != null)
        {
            ViewGroup parent = (ViewGroup) webViewFrame.getParent();
            parent.removeView(webViewFrame);

            currentInstance  = null;
        }
    }

    public static void show(final String tag)
    {
        Runnable runnableThread = new Runnable()
        {
            @Override
            public void run()
            {
                Activity currentActivity = NativePluginHelper.getCurrentActivity();
                Bundle bundle = new Bundle();
                bundle.putString("Tag", tag);

                Intent intent = new Intent(currentActivity, WebviewActivity.class);
                intent.putExtras(bundle);

                currentActivity.startActivity(intent);
            }
        };

        NativePluginHelper.executeOnUIThread(runnableThread);
    }

    public static void close()
    {
        if(currentInstance != null)
        {
            currentInstance.finish();
        }
    }
}
