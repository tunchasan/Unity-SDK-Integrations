package com.voxelbusters.nativeplugins.features.billing.core.datatypes;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * Created by ayyappa on 28/03/16.
 */
public class BillingTransaction
{
    public String   productIdentifier;
    public long     transactionDate;
    public String   transactionIdentifier;
    public String   transactionReceipt;
    public String   transactionState;
    public String   verificationState;
    public String   error;
    public String   rawPurchaseData; // This should be the original json

    public JSONObject getJsonObject()
    {
        JSONObject jsonObject = new JSONObject();

        try
        {
            jsonObject.put("product-identifier",productIdentifier);
            jsonObject.put("transaction-date",transactionDate);
            jsonObject.put("transaction-identifier",transactionIdentifier);
            jsonObject.put("transaction-receipt",transactionReceipt);
            jsonObject.put("transaction-state",transactionState);
            jsonObject.put("verification-state",verificationState);
            jsonObject.put("error",error);
            jsonObject.put("raw-purchase-data", rawPurchaseData);
        } catch (JSONException e) {
            e.printStackTrace();
        }


        return  jsonObject;
    }

}
