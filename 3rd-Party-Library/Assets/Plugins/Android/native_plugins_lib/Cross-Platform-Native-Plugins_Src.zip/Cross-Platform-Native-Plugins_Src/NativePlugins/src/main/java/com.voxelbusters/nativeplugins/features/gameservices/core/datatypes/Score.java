package com.voxelbusters.nativeplugins.features.gameservices.core.datatypes;

import com.voxelbusters.nativeplugins.defines.Keys;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;

/**
 * Created by ayyappa on 11/05/16.
 */
public class Score
{
    public String                   identifier;
    public User                     user;
    public long                     value;
    public long                     date;
    public String                   formattedValue;
    public long                     rank;

    public JSONObject getHashMap()
    {
        JSONObject jsonObject = new JSONObject();
        try
        {
            jsonObject.put(Keys.GameServices.SCORE_ID, identifier);
            if (user != null)
            {
                jsonObject.put(Keys.GameServices.SCORE_USER, user.getHashMap());
            }

            jsonObject.put(Keys.GameServices.SCORE_VALUE, value);
            jsonObject.put(Keys.GameServices.SCORE_DATE, date);
            jsonObject.put(Keys.GameServices.SCORE_FORMATTED_VALUE, formattedValue);
            jsonObject.put(Keys.GameServices.SCORE_RANK, rank);
        } catch (JSONException e) {
            e.printStackTrace();
        }



        return jsonObject;
    }
}
